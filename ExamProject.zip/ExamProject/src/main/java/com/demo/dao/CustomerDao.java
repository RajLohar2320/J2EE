package com.demo.dao;

import java.util.List;

import com.demo.model.Customer;

public interface CustomerDao {
	int save(Customer c);
	List<Customer> getAll();
	Customer getById(String cid);
	int updateById(Customer c);
	int deleteById(String cid);
}
