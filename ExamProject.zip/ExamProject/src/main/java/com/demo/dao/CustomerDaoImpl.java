package com.demo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.RowMapper;

import com.demo.model.Customer;

@Repository
public class CustomerDaoImpl implements CustomerDao{
	@Autowired
	private JdbcTemplate jdbcTemp;
	public int save(Customer c) {
		return jdbcTemp.update("INSERT into Customers VALUES(?,?,?)", new Object[] {c.getCid(), c.getBasePack(), c.getOpPack()});
	}

	public List<Customer> getAll() {
		List<Customer> clist = jdbcTemp.query("SELECT * FROM Customers", new RowMapper<Customer>() {
			public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
				Customer c = new Customer(rs.getString(1), rs.getString(2), rs.getString(3));
				return c;
			}
		});
		return clist;
	}

	public Customer getById(String cid) {
		RowMapper<Customer> crm = new RowMapper<Customer>() {
			public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
				Customer c = new Customer(rs.getString(1), rs.getString(2), rs.getString(3));
				return c;
			}
		};
		return jdbcTemp.queryForObject("SELECT * FROM Customers WHERE Cust_no = ?", crm, cid);
	}

	public int updateById(Customer c) {
		return jdbcTemp.update("UPDATE Customers set BasePack = ? WHERE Cust_no = ?", new Object[] {c.getBasePack(), c.getCid()});
	}

	public int deleteById(String cid) {
		return jdbcTemp.update("DELETE FROM Customers WHERE Cust_no = ?", new Object[] {cid});
	}

}
