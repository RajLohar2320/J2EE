package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.demo.model.Customer;
import com.demo.service.CustomerService;

@Controller
@RequestMapping("/")
public class CustomerController {
	@Autowired
	private CustomerService cserv;
	
	@GetMapping("/")
	public ModelAndView home() {
		return new ModelAndView("Home");
	}
	
	@GetMapping("/displayAll")
	public ModelAndView displayAll() {
		List<Customer> clist = cserv.showAll();
		return new ModelAndView("Customers","clist", clist);
	}
	
	@GetMapping("/customer")
	public ModelAndView showById() {
		return new ModelAndView("Form");
	}
	
	@PostMapping("/getCust/{cid}")
	public ModelAndView showById(@PathVariable("cid") String cid) {
		Customer c = cserv.showById(cid);
		System.out.println(c);
		return new ModelAndView("ShowCust", "cust", c);
	}
	
	@GetMapping("/edit")
	public ModelAndView edit() {
		return new ModelAndView("Edit");
	}
	
	@PostMapping("/update")
	public ModelAndView update(@RequestParam("cid") String cid, @RequestParam("basePack") String basePack) {
		Customer c = new Customer(cid, basePack, "None");
		cserv.upById(c);
		return new ModelAndView("redirect://");
		
	}

}
