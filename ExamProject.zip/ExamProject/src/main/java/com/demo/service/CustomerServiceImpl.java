package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.CustomerDao;
import com.demo.model.Customer;
@Service
public class CustomerServiceImpl implements CustomerService{
	@Autowired
	private CustomerDao cdao;
	
	public int insert(Customer c) {
		return cdao.save(c);
	}

	public List<Customer> showAll() {
		return cdao.getAll();
	}

	public Customer showById(String cid) {
		return cdao.getById(cid);
	}

	public int upById(Customer c) {
		return cdao.updateById(c);
	}

	public int delById(String cid) {
		return cdao.deleteById(cid);
	}
	
}
