package com.demo.service;

import java.util.List;

import com.demo.model.Customer;

public interface CustomerService {
	int insert(Customer c);
	List<Customer> showAll();
	Customer showById(String cid);
	int upById(Customer c);
	int delById(String cid);
}
