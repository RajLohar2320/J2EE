package com.demo.model;

import org.springframework.stereotype.Component;

@Component
public class Customer {
	private String cid;
	private String basePack;
	private String opPack;
	public Customer() {
		super();
	}
	public Customer(String cid, String basePack, String opPack) {
		super();
		this.cid = cid;
		this.basePack = basePack;
		this.opPack = opPack;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getBasePack() {
		return basePack;
	}
	public void setBasePack(String basePack) {
		this.basePack = basePack;
	}
	public String getOpPack() {
		return opPack;
	}
	public void setOpPack(String opPack) {
		this.opPack = opPack;
	}
	@Override
	public String toString() {
		return "Customer [Customer_ID=" + cid + ", Base_Pack=" + basePack + ", Optional_Pack=" + opPack + "]";
	}
	
}
